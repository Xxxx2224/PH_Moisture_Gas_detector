namespace TeknolojiTasarım1.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
	public class xxx
	{
		public string id { get; set; }
		public string baslık { get; set; }
		public string fiyat { get; set; }
		public string kategori { get; set; }
        public string resim { get; set; }
    }
    public class xxx1
    {
        public string id { get; set; }
        public string baslık { get; set; }
        public string fiyat { get; set; }
        public string kategori { get; set; }
        public string resim { get; set; }
    }
    public class xxx12
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
